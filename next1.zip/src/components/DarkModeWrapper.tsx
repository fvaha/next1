"use client";

import React, { useState, useEffect, createContext, useContext } from "react";

// Dark mode context shared across components
const DarkModeContext = createContext<{
  dark: boolean;
  toggleDark: () => void;
}>({
  dark: true,
  toggleDark: () => {},
});

export const useDarkMode = () => useContext(DarkModeContext);

export default function DarkModeWrapper({
  children,
}: {
  children: React.ReactNode;
}) {
  const [dark, setDark] = useState(true);

  // Load saved theme from localStorage and set <html> class
  useEffect(() => {
    const saved =
      typeof window !== "undefined" ? localStorage.getItem("darkMode") : null;
    const isDark = saved ? JSON.parse(saved) : true;
    setDark(isDark);

    // Set the <html> class immediately on mount
    if (isDark) {
      document.documentElement.classList.add("dark");
    } else {
      document.documentElement.classList.remove("dark");
    }
  }, []);

  // Whenever dark changes, update localStorage and <html> class
  useEffect(() => {
    if (typeof window !== "undefined") {
      localStorage.setItem("darkMode", JSON.stringify(dark));
      if (dark) {
        document.documentElement.classList.add("dark");
      } else {
        document.documentElement.classList.remove("dark");
      }
    }
  }, [dark]);

  const toggleDark = () => setDark((prev) => !prev);

  return (
    <DarkModeContext.Provider value={{ dark, toggleDark }}>
      {children}
    </DarkModeContext.Provider>
  );
}
