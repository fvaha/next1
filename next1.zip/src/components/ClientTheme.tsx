"use client";

import { useDarkMode } from "./DarkModeWrapper";
import { useEffect } from "react";

export default function ClientTheme({
  children,
}: {
  children: React.ReactNode;
}) {
  const { dark } = useDarkMode();

  useEffect(() => {
    if (dark) {
      document.documentElement.classList.add("dark");
    } else {
      document.documentElement.classList.remove("dark");
    }
  }, [dark]);

  return <>{children}</>;
}
