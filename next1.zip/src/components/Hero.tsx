"use client";
import React, { useEffect, useState } from "react";
import Image from "next/image";
import { useLang } from "./LanguageContext";
import EllipticCurveCanvas from "./EllipticCurveCanvas";
import { Slide } from "../types/slide";

// Import slides translations
import { slides as slidesEn } from "../data/slides.en";
import { slides as slidesDe } from "../data/slides.de";
import { slides as slidesFr } from "../data/slides.fr";
import { slides as slidesAr } from "../data/slides.ar";
import { slides as slidesCr } from "../data/slides.cr";
import { slides as slidesNo } from "../data/slides.no";
import { slides as slidesRu } from "../data/slides.ru";
import { slides as slidesSp } from "../data/slides.sp";

// Map language code to slides
const slidesMap: Record<string, Slide[]> = {
  en: slidesEn,
  de: slidesDe,
  fr: slidesFr,
  ar: slidesAr,
  cr: slidesCr,
  no: slidesNo,
  ru: slidesRu,
  sp: slidesSp,
};

const Hero: React.FC = () => {
  const { lang, t } = useLang();
  const slides = slidesMap[lang] || slidesEn;

  const [currentSlide, setCurrentSlide] = useState(0);
  const [isDark, setIsDark] = useState(false);

  // Listen to dark mode toggle
  useEffect(() => {
    const html = document.documentElement;
    const updateDark = () => setIsDark(html.classList.contains("dark"));
    updateDark();
    const observer = new MutationObserver(updateDark);
    observer.observe(html, { attributes: true, attributeFilter: ["class"] });
    return () => observer.disconnect();
  }, []);

  // Auto-rotate slides
  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % slides.length);
    }, 8000);
    return () => clearInterval(timer);
  }, [slides.length]);

  // Styles to perfectly match old project (background, text fade, etc.)
  const bgStyle = isDark
    ? { backgroundColor: "#121212" }
    : { backgroundColor: "#fff" };

  return (
    <section
      className="relative flex flex-col items-center justify-start min-h-screen pt-20 pb-12 text-center transition-colors duration-300 overflow-hidden"
      style={bgStyle}
    >
      {/* 3D animated canvas background */}
      <EllipticCurveCanvas isDark={isDark} />

      {/* Logo */}
      <div className="mb-12 z-10">
        <Image
          src="/logo.png"
          alt="TerraCrypt"
          width={192}
          height={192}
          className="w-48 h-48 mx-auto object-contain"
          priority
        />
      </div>

      {/* Slides (fading animation, only one visible) */}
      <div className="relative w-full flex-grow flex flex-col items-center justify-start z-10">
        {slides.map((slide, index) => (
          <div
            key={index}
            className={`absolute w-full flex flex-col items-center justify-center transition-opacity duration-1000 ${
              currentSlide === index
                ? "opacity-100 z-10"
                : "opacity-0 z-0 pointer-events-none"
            }`}
            style={{
              transitionProperty: "opacity",
              // Optionally: only render visible or previous (to avoid layout shift)
            }}
          >
            <h1 className="text-5xl md:text-6xl font-extrabold text-gold mb-4 px-4 drop-shadow">
              {slide.title}
            </h1>
            <p
              className={`text-lg md:text-2xl ${
                isDark ? "text-neutral-300" : "text-neutral-700"
              } max-w-xl mb-8 px-4`}
            >
              {slide.description}
            </p>
            <a
              href={slide.link}
              className="bg-gold text-neutral-900 font-bold px-8 py-3 rounded shadow hover:bg-yellow-400 transition-colors duration-200"
            >
              {slide.cta}
            </a>
          </div>
        ))}
      </div>

      {/* Slide dots */}
      <div className="absolute bottom-4 left-0 right-0 flex justify-center space-x-2 z-20">
        {slides.map((_, index) => (
          <button
            key={index}
            onClick={() => setCurrentSlide(index)}
            className={`w-3 h-3 rounded-full transition-colors ${
              currentSlide === index
                ? "bg-gold"
                : "bg-neutral-400 dark:bg-neutral-600"
            }`}
            aria-label={`${t?.hero?.slideAria || "Go to slide"} ${index + 1}`}
          />
        ))}
      </div>
    </section>
  );
};

export default Hero;
