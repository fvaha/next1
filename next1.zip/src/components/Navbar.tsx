"use client";
import React, { useState, useRef, useEffect } from "react";
import { TbSun, TbMoon, TbMenu2 } from "react-icons/tb";
import { useDarkMode } from "./DarkModeWrapper";
import { useLang } from "./LanguageContext";

const Navbar: React.FC = () => {
  const { dark, toggleDark } = useDarkMode();
  const { lang, setLang, t, languages } = useLang();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [showLang, setShowLang] = useState(false);

  // Close language dropdown on outside click
  const langRef = useRef<HTMLDivElement>(null);
  useEffect(() => {
    function handleClick(e: MouseEvent) {
      if (langRef.current && !langRef.current.contains(e.target as Node)) {
        setShowLang(false);
      }
    }
    if (showLang) window.addEventListener("mousedown", handleClick);
    return () => window.removeEventListener("mousedown", handleClick);
  }, [showLang]);

  return (
    <nav className="sticky top-0 z-50 bg-white dark:bg-black border-b border-gold/50 shadow transition-colors duration-300">
      <div className="max-w-7xl mx-auto flex items-center justify-between py-3 px-6">
        <span className="text-xl font-bold text-gold select-none tracking-tight">
          TerraCrypt
        </span>
        <div className="block md:hidden bg-red-400 text-white p-2">
          Mobile only
        </div>
        <div className="hidden md:block bg-green-400 text-white p-2">
          Desktop only
        </div>

        {/* Desktop nav */}
        <div className="hidden md:flex items-center space-x-4">
          <div className="flex space-x-6">
            <a
              href="#features"
              className="hover:text-gold font-medium transition-colors"
            >
              {t.nav.features}
            </a>
            <a
              href="#faq"
              className="hover:text-gold font-medium transition-colors"
            >
              {t.nav.faq}
            </a>
            <a
              href="#contact"
              className="hover:text-gold font-medium transition-colors"
            >
              {t.nav.contact}
            </a>
          </div>
          <button
            onClick={toggleDark}
            className="ml-3 p-2 rounded bg-neutral-200 text-neutral-800 hover:bg-gold hover:text-neutral-900 dark:bg-neutral-800 dark:hover:bg-gold dark:text-white dark:hover:text-neutral-900 transition"
            aria-label="Toggle dark mode"
          >
            {dark ? (
              <TbSun className="w-5 h-5" />
            ) : (
              <TbMoon className="w-5 h-5" />
            )}
          </button>
          <div className="relative" ref={langRef}>
            <button
              onClick={() => setShowLang((v) => !v)}
              className="ml-2 px-3 py-2 rounded bg-neutral-100 dark:bg-neutral-800 border border-gold/40 text-sm font-medium hover:text-gold transition"
            >
              {languages.find((l) => l.code === lang)?.label || lang}
            </button>
            {showLang && (
              <div className="absolute right-0 mt-2 w-32 bg-white dark:bg-neutral-900 border border-gold/20 rounded shadow z-50 animate-fadeIn">
                {languages.map((l) => (
                  <button
                    key={l.code}
                    onClick={() => {
                      setLang(l.code);
                      setShowLang(false);
                    }}
                    className={`block w-full text-left px-4 py-2 hover:bg-gold/20 dark:hover:bg-gold/40 transition-colors ${
                      lang === l.code ? "font-bold text-gold" : ""
                    }`}
                  >
                    {l.label}
                  </button>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Mobile menu toggle */}
        <div className="md:hidden flex items-center space-x-2">
          <button
            onClick={toggleDark}
            className="p-2 rounded bg-neutral-200 text-neutral-800 hover:bg-gold hover:text-neutral-900 dark:bg-neutral-800 dark:hover:bg-gold dark:text-white dark:hover:text-neutral-900 transition"
            aria-label="Toggle dark mode"
          >
            {dark ? (
              <TbSun className="w-5 h-5" />
            ) : (
              <TbMoon className="w-5 h-5" />
            )}
          </button>
          <button
            onClick={() => setIsMobileMenuOpen((v) => !v)}
            className="p-2 rounded text-neutral-800 dark:text-white hover:bg-neutral-200 dark:hover:bg-neutral-800 transition"
            aria-label="Toggle menu"
          >
            <TbMenu2 className="w-6 h-6" />
          </button>
        </div>
      </div>
      {/* Mobile dropdown */}
      {isMobileMenuOpen && (
        <div className="md:hidden bg-white dark:bg-black py-2 px-4 border-t border-gold/10 shadow-lg animate-fadeIn">
          <div className="flex flex-col space-y-3">
            <a
              href="#features"
              onClick={() => setIsMobileMenuOpen(false)}
              className="hover:text-gold font-medium transition py-2"
            >
              {t.nav.features}
            </a>
            <a
              href="#faq"
              onClick={() => setIsMobileMenuOpen(false)}
              className="hover:text-gold font-medium transition py-2"
            >
              {t.nav.faq}
            </a>
            <a
              href="#contact"
              onClick={() => setIsMobileMenuOpen(false)}
              className="hover:text-gold font-medium transition py-2"
            >
              {t.nav.contact}
            </a>
            <div className="border-t border-gold/10 pt-3">
              {languages.map((l) => (
                <button
                  key={l.code}
                  onClick={() => {
                    setLang(l.code);
                    setShowLang(false);
                    setIsMobileMenuOpen(false);
                  }}
                  className={`block w-full text-left px-4 py-2 hover:bg-gold/20 dark:hover:bg-gold/40 transition-colors ${
                    lang === l.code ? "font-bold text-gold" : ""
                  }`}
                >
                  {l.label}
                </button>
              ))}
            </div>
          </div>
        </div>
      )}
    </nav>
  );
};

export default Navbar;
