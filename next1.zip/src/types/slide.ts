export interface Slide {
  title: string;
  description: string;
  cta: string;
  link: string;
}
